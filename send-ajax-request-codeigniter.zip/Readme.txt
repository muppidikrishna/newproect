Author: Yogesh singh
Author URL: http://makitweb.com/
Author Email: yssyogesh@makitweb.com
Tutorial Link: http://makitweb.com/insert-record-to-database-table-codeigniter/

#######################################################

### Instructions - 

* base_url
Rename the folder and edit $config['base_url'] in application/config/config.php

* Database connection
Update database connection in application/config/database.php

* Import attached users.sql file in your database.
